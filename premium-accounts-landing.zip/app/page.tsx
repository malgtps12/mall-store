import Header from './components/Header'
import Hero from './components/Hero'
import Stats from './components/Stats'
import ProductDisplay from './components/ProductDisplay'
import Footer from './components/Footer'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-purple-50 to-white">
      <div className="mx-auto max-w-7xl">
        <Header />
        <main>
          <Hero />
          <Stats />
          <ProductDisplay />
        </main>
        <Footer />
      </div>
    </div>
  )
}

