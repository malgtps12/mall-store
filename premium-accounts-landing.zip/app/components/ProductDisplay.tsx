'use client'

import { useState } from 'react'
import ProductCard from './ProductCard'
import PricingModal from './PricingModal'

const products = [
  { id: 1, name: 'YouTube Premium', price: 17000, duration: 'Full Garansi', type: 'Individual' },
  { id: 2, name: 'Netflix', price: 11000, duration: '1 Minggu', type: 'Shared 1P2U' },
  { id: 3, name: 'Netflix', price: 15000, duration: '2 Minggu', type: 'Shared 1P2U' },
  { id: 4, name: 'Netflix', price: 22000, duration: '1 Bulan', type: 'Shared 1P2U' },
  { id: 5, name: 'Netflix', price: 14000, duration: '1 Minggu', type: 'Shared 1P1U' },
  { id: 6, name: 'Netflix', price: 32000, duration: '1 Bulan', type: 'Shared 1P1U' },
  { id: 7, name: 'Netflix', price: 135000, duration: '1 Bulan', type: 'Private' },
  { id: 8, name: 'Amazon Prime', price: 9000, duration: '1 Bulan', type: 'Shared' },
  { id: 9, name: 'Amazon Prime', price: 19000, duration: '1 Bulan', type: 'Private' },
  { id: 10, name: 'Disney+', price: 27000, duration: '1 Bulan', type: 'Shared 6U' },
  { id: 11, name: 'iQIYI', price: 12000, duration: '1 Bulan', type: 'Shared' },
  { id: 12, name: 'iQIYI', price: 15000, duration: '1 Tahun', type: 'Shared' },
  { id: 13, name: 'Viu', price: 7000, duration: '2 Bulan', type: 'Shared' },
  { id: 14, name: 'Viu', price: 10000, duration: '4 Bulan', type: 'Shared' },
  { id: 15, name: 'Viu', price: 12000, duration: '7 Bulan', type: 'Shared' },
  { id: 16, name: 'Viu', price: 14000, duration: '1 Tahun', type: 'Shared' },
  { id: 17, name: 'WeTV', price: 12000, duration: '1 Bulan', type: 'Shared 6U' },
  { id: 18, name: 'WeTV', price: 35000, duration: '1 Bulan', type: 'Private' },
  { id: 19, name: 'Youku', price: 12000, duration: '1 Tahun', type: 'Shared' },
  { id: 20, name: 'Bilibili', price: 12000, duration: '1 Tahun', type: 'Shared' },
  { id: 21, name: 'Loklok', price: 7000, duration: '1 Bulan', type: 'Shared' },
  { id: 22, name: 'Loklok', price: 11000, duration: '3 Bulan', type: 'Shared' },
  { id: 23, name: 'Loklok', price: 19000, duration: '1 Tahun', type: 'Shared' },
  { id: 24, name: 'Canva', price: 17000, duration: '1 Bulan', type: 'Owner' },
  { id: 25, name: 'Canva', price: 12000, duration: 'Lifetime', type: 'Lifetime' },
  { id: 26, name: 'PicsArt', price: 13000, duration: '1 Bulan', type: 'Private' },
  { id: 27, name: 'CapCut', price: 8000, duration: '1 Bulan', type: 'Shared' },
  { id: 28, name: 'CapCut', price: 19000, duration: '1 Tahun', type: 'Shared' },
  { id: 29, name: 'AutoMod', price: 3500, duration: '1 Tahun', type: 'Shared' },
  { id: 30, name: 'AutoMod', price: 5000, duration: '1 Tahun', type: 'Private' },
  { id: 31, name: 'VSCO', price: 12000, duration: '1 Tahun', type: 'Shared Plus' },
  { id: 32, name: 'VSCO', price: 20000, duration: '1 Tahun', type: 'Shared Pro' },
  { id: 33, name: 'Lightroom', price: 10000, duration: '6 Bulan', type: 'Shared' },
  { id: 34, name: 'Lightroom', price: 17000, duration: '1 Tahun', type: 'Shared' },
  { id: 35, name: 'Dazzcam', price: 18000, duration: 'Lifetime', type: 'Shared' },
  { id: 36, name: 'Oldrool Android', price: 14000, duration: 'Lifetime', type: 'Shared' },
  { id: 37, name: 'Photoroom', price: 24000, duration: '1 Tahun', type: 'Shared' },
  { id: 38, name: 'Vision+', price: 29000, duration: '1 Bulan', type: 'Private' },
  { id: 39, name: 'Vision+', price: 19000, duration: '1 Bulan', type: 'Shared 2U' },
  { id: 40, name: 'Drakorid', price: 12000, duration: '1 Tahun', type: 'Shared' },
  { id: 41, name: 'GTC', price: 10000, duration: '1 Bulan', type: 'Private' },
  { id: 42, name: 'Wattpad', price: 12000, duration: '6 Bulan', type: 'Shared' },
  { id: 43, name: 'Wattpad', price: 14000, duration: '1 Tahun', type: 'Shared' },
  { id: 44, name: 'Brainly', price: 14000, duration: '1 Tahun', type: 'Shared' },
  { id: 45, name: 'HBO GO', price: 60000, duration: '1 Bulan', type: 'Private' },
  { id: 46, name: 'HBO GO', price: 112000, duration: '3 Bulan', type: 'Private' },
  { id: 47, name: 'CamScanner', price: 16000, duration: '1 Tahun', type: 'Shared' },
  { id: 48, name: 'Scribd', price: 18000, duration: '1 Bulan', type: 'Private' },
  { id: 49, name: 'Scribd', price: 11000, duration: '1 Bulan', type: 'Shared' },
  { id: 50, name: 'Remini Lite Android', price: 19000, duration: '1 Tahun', type: 'Shared' },
  { id: 51, name: 'Remini Pro Android', price: 29000, duration: '1 Tahun', type: 'Shared' },
  { id: 52, name: 'Wink', price: 17000, duration: '1 Tahun', type: 'Shared' },
  { id: 53, name: 'Mathway Plus', price: 16000, duration: '1 Tahun', type: 'Shared' },
  { id: 54, name: 'Crunchyroll', price: 19000, duration: '1 Tahun', type: 'Shared' },
  { id: 55, name: 'Wibuku', price: 14000, duration: '1 Bulan', type: 'Shared' },
  { id: 56, name: 'Wibuku', price: 22000, duration: '6 Bulan', type: 'Shared' },
  { id: 57, name: 'Vidio Platinum', price: 28500, duration: '1 Bulan', type: 'Private' },
  { id: 58, name: 'Spotify', price: 20000, duration: '2 Bulan', type: 'No Garansi' },
  { id: 59, name: 'Youku', price: 7000, duration: '1 Bulan', type: 'Shared' },
  { id: 60, name: 'Youku', price: 10000, duration: '3 Bulan', type: 'Shared' },
  { id: 61, name: 'CamScanner', price: 18000, duration: '1 Tahun', type: 'Shared' },
  { id: 62, name: 'Vidio Platinum', price: 29000, duration: '1 Bulan', type: 'Private' },
  { id: 63, name: 'Canva', price: 5000, duration: '1 Bulan', type: 'Shared' },
  { id: 64, name: 'Canva', price: 7000, duration: '2 Bulan', type: 'Shared' },
  { id: 65, name: 'Canva', price: 8000, duration: '3 Bulan', type: 'Shared' },
  { id: 66, name: 'Canva', price: 9000, duration: '4 Bulan', type: 'Shared' },
  { id: 67, name: 'Canva', price: 10000, duration: '5 Bulan', type: 'Shared' },
  { id: 68, name: 'Canva', price: 11000, duration: '6 Bulan', type: 'Shared' },
  { id: 69, name: 'Canva', price: 17000, duration: '1 Tahun', type: 'Shared' },
]

export default function ProductDisplay() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <section id="product-display" className="py-16">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Our Premium Accounts</h2>
          <p className="text-gray-600">Select from our wide range of premium services</p>
        </div>
        <div className="mb-8">
          <input
            type="text"
            placeholder="Search accounts..."
            className="w-full px-4 py-2 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-600"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onViewPrices={() => setSelectedProduct(product)}
            />
          ))}
        </div>
      </div>
      {selectedProduct && (
        <PricingModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />
      )}
    </section>
  )
}

