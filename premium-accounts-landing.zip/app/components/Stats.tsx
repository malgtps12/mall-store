export default function Stats() {
  return (
    <section id="stats" className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto py-16 px-4">
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 text-center">
        <h3 className="text-4xl font-bold mb-2">17+</h3>
        <p className="text-gray-600">Premium Services</p>
      </div>
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 text-center">
        <h3 className="text-4xl font-bold mb-2">5k+</h3>
        <p className="text-gray-600">Happy Customers</p>
      </div>
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 text-center">
        <h3 className="text-4xl font-bold mb-2">24/7</h3>
        <p className="text-gray-600">Support</p>
      </div>
    </section>
  )
}

