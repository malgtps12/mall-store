'use client'

import Link from 'next/link'
import { Box } from 'lucide-react'
import { usePathname } from 'next/navigation'

export default function Header() {
  const pathname = usePathname()

  return (
    <header className="px-4 py-6">
      <nav className="flex items-center justify-between">
        <Link href="/" className="flex items-center space-x-2">
          <Box className="w-8 h-8 text-purple-600" />
          <span className="text-xl font-bold">Mall Store</span>
        </Link>
        <div className="hidden md:flex items-center space-x-8">
          <a
            href="#hero"
            className={`${
              pathname === '/' ? 'text-purple-600' : 'text-gray-600'
            } hover:text-purple-600 transition-colors`}
          >
            Home
          </a>
          <a
            href="#stats"
            className="text-gray-600 hover:text-purple-600 transition-colors"
          >
            Stats
          </a>
          <a
            href="#product-display"
            className="text-gray-600 hover:text-purple-600 transition-colors"
          >
            Products
          </a>
        </div>
        <Link
          href="https://wa.me/6289516353968"
          className="bg-purple-600 text-white px-6 py-2 rounded-full hover:bg-purple-700 transition-colors"
        >
          Contact
        </Link>

      </nav>
    </header>
  )
}

