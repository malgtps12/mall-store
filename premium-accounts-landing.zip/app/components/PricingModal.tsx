interface PricingModalProps {
  product: {
    name: string
    price: number
    duration: string
    type: string
  }
  onClose: () => void
}

export default function PricingModal({ product, onClose }: PricingModalProps) {
  const handleWhatsAppCheckout = () => {
    const message = `Hi, I would like to purchase ${product.name} (${product.type}) for ${product.duration} at ${product.price.toLocaleString()} IDR`
    const whatsappUrl = `https://wa.me/6289516353968?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, '_blank')
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full">
        <h2 className="text-2xl font-bold mb-6">{product.name}</h2>
        <div className="space-y-4">
          <div className="bg-gray-50 rounded-xl p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="font-semibold">{product.type}</p>
                <p className="text-sm text-gray-600">{product.duration}</p>
              </div>
              <div className="text-right">
                <p className="font-bold">{product.price.toLocaleString()} IDR</p>
                <button
                  onClick={handleWhatsAppCheckout}
                  className="text-purple-600 hover:text-purple-700 font-medium text-sm"
                >
                  Purchase via WhatsApp
                </button>
              </div>
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="mt-6 w-full bg-gray-100 text-gray-800 font-bold py-2 px-4 rounded-full hover:bg-gray-200 transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  )
}

