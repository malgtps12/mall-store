export default function Hero() {
  return (
    <section className="text-center py-20 px-4">
      <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold max-w-4xl mx-auto leading-tight mb-6">
        Affordable Premium Accounts at Your Fingertips
      </h1>
      <p className="text-gray-600 text-xl max-w-2xl mx-auto mb-12">
        Choose from our wide selection of streaming, productivity, and entertainment accounts.
      </p>
      <button
        onClick={() => document.getElementById('product-display')?.scrollIntoView({ behavior: 'smooth' })}
        className="bg-purple-600 text-white px-8 py-3 rounded-full text-lg font-medium hover:bg-purple-700 transition-transform hover:scale-105"
      >
        Explore Deals
      </button>
    </section>
  )
}

