interface ProductCardProps {
  product: {
    name: string
    price: number
    duration: string
    type: string
  }
  onViewPrices: () => void
}

export default function ProductCard({ product, onViewPrices }: ProductCardProps) {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 hover:scale-105 transition-all duration-300 shadow-lg">
      <div className="mb-4">
        <span className="text-sm text-purple-600 font-medium">{product.type}</span>
        <h3 className="text-xl font-bold mt-2">{product.name}</h3>
        <p className="text-3xl font-bold mt-4">
          {product.price.toLocaleString()} IDR
          <span className="text-sm text-gray-600 font-normal">/{product.duration}</span>
        </p>
      </div>
      <button
        onClick={onViewPrices}
        className="w-full bg-purple-600 text-white py-2 rounded-full hover:bg-purple-700 transition-colors"
      >
        View Details
      </button>
    </div>
  )
}

