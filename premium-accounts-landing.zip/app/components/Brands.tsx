export default function Brands() {
  return (
    <section className="py-16 px-4">
      <div className="text-center mb-12">
        <p className="text-gray-600">Trusted by 50,000+ users worldwide</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center justify-items-center opacity-50">
        {[1, 2, 3, 4, 5, 6].map((index) => (
          <div key={index} className="h-12">
            <img
              src={`/placeholder.svg?height=48&width=120`}
              alt={`Brand ${index}`}
              className="h-full object-contain"
            />
          </div>
        ))}
      </div>
    </section>
  )
}

